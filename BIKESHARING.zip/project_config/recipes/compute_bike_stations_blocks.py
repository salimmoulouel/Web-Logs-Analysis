# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import requests
import pandas as pd
# Recipe inputs
ds = dataiku.Dataset("bike_stations_prepared")
ds_df=ds.get_dataframe()



"""
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
bike_stations_prepared = dataiku.Dataset("bike_stations_prepared")
bike_stations_prepared_df = bike_stations_prepared.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

bike_stations_blocks_df = bike_stations_prepared_df # For this sample code, simply copy input to output


# Write recipe outputs
bike_stations_blocks = dataiku.Dataset("bike_stations_blocks")
bike_stations_blocks.write_with_schema(bike_stations_blocks_df)
"""

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Helper function to get the blocks
## Mind this is your task to make it working.
def get_block(lat, lon):
    data = {
      'format': 'json',
      'y': lat,
      'x': lon,
      'benchmark':4,
      'vintage':4
    }
    r = requests.get('https://geocoding.geo.census.gov/geocoder/geographies/coordinates', params=data)
    if r.status_code == 200:
        return r.json()
    else:
        return None

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Actual logic
results = []
for record in ds.iter_rows():
    o = {}
    o['station_id']  = record['id']
    block_group=get_block(record['lat'],record['long'])['result']['geographies']['2010 Census Blocks'][0]['GEOID']
    #block_group=str(block_group)
    o['block_group'] =block_group[0:12]
    results.append(o)
odf = pd.DataFrame(results)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Recipe outputs
bsb = dataiku.Dataset("bike_stations_blocks")
bsb.write_with_schema(odf)