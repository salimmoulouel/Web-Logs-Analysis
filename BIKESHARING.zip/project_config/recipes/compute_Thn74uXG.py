# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import os
import urllib
import dataiku
# Settings
YEARS = ['2012', '2011', '2010']
# Recipe outputs
bike_trips_data = dataiku.Folder("NfY2tfEj")
bike_trips_data_path = bike_trips_data.get_path()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Download the files
retriever = urllib.URLopener()
base_url = 'https://s3.amazonaws.com/capitalbikeshare-data'
suffix   = '-capitalbikeshare-tripdata.zip' #previously => '_trip_history_data.zip' ; please check by yourself if the structure is still the same.
for year in YEARS:
    filename = '{}{}'.format(year, suffix)
    source_url = '{}/{}'.format(base_url, filename)
    target_dir = os.path.join(bike_trips_data_path, filename)
    retriever.retrieve(source_url, target_dir)
    print '[+] Downloaded {}...'.format(filename)