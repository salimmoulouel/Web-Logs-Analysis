# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import os
import dataiku
import pandas as pd
DATE = dataiku.dku_flow_variables["DKU_DST_DATE"].replace('-','')
print(DATE)
# Recipe inputs
in_folder = dataiku.Folder("2O96gBUH")
in_path = in_folder.get_path()
# Read in data
file_name = 'capitalbikeshare_trip_data_' + DATE + '.csv'
file_path = os.path.join(in_path, file_name)
print '[+] Processing file: {}'.format(file_name)
df = pd.read_csv(file_path, sep='|', quotechar='"')
# Recipe outputs
bike_dataset = dataiku.Dataset("bike_dataset")
bike_dataset.write_with_schema(df)