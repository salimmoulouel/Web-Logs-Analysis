# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
jokes_copy_to_join_joined_prepared1 = dataiku.Dataset("jokes_copy_to_join_joined_prepared1")
jokes_copy_to_join_joined_prepared1_df = jokes_copy_to_join_joined_prepared1.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

notes_moyenne_mot_df = jokes_copy_to_join_joined_prepared1_df # For this sample code, simply copy input to output


# Write recipe outputs
#notes_moyenne_mot = dataiku.Dataset("notes_moyenne_mot")
#notes_moyenne_mot.write_with_schema(notes_moyenne_mot_df)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
notes_moyenne_mot_df.head()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import json
noteUser={}
noteBlague={}
for i,j in notes_moyenne_mot_df.iterrows():
    blague=json.loads(j[0])

    for w in blague:
        mot=unicode(w)
        if not(mot in noteUser):
            noteUser[mot]={}
        if j[1] in noteUser[mot]:#si utilisateur dans deja connu
            noteUser[mot][j[1]][j[2]]=j[3]
        else:
            noteUser[mot][j[1]]={j[2]:j[3]}
        if not ( mot in noteBlague ):
            noteBlague[mot]={}
        if (j[2] in noteBlague[mot]):
            noteBlague[mot][j[2]][j[1]]=j[3]
        else:
            noteBlague[mot][j[2]]={j[1]:j[3]}

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
noteBlague["irishmen"]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
moyenneUser={}
moyenneBlague={}
for mot in list(noteBlague.keys()):
    nbB=0
    sommeBlagues=0
    for blague in noteBlague[mot]:
        nbB+=len(noteBlague[mot][blague].values())
        sommeBlagues+=np.sum(noteBlague[mot][blague].values())
    moyenneBlague[mot]=sommeBlagues/nbB
for mot in noteUser:
    nbU=0
    for user in noteUser[mot].keys():
        if not (mot in moyenneUser):
            moyenneUser[mot]={}
        moyenneUser[mot][user]=np.mean(noteUser[mot][user].values())

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
dflist=[]
for mot in moyenneUser.keys():
    for user in moyenneUser[mot].keys():

        dflist.append( [mot,user, moyenneUser[mot][user], moyenneBlague[mot] ])
dfres=pd.DataFrame(dflist,columns=['mot','user','moyenne_user','moyenneBlague'])
# Write recipe outputs

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
dfres[dfres.mot=="visit"]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
notes_moyenne_mot = dataiku.Dataset("notes_moyenne_mot")
notes_moyenne_mot.write_with_schema(dfres)