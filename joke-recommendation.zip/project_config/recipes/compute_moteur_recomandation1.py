# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
jokes_tokenized_by_text_joined = dataiku.Dataset("jokes_tokenized_by_text_joined")
jokes_tokenized_by_text_joined_df = jokes_tokenized_by_text_joined.get_dataframe()

test = dataiku.Dataset("test")
test_df = test.get_dataframe()

my_jokes=dataiku.Dataset("jokes_copy_to_join_prepared")
my_jokes_df=my_jokes.get_dataframe()


jokes_info_df=jokes_tokenized_by_text_joined_df.copy()
rating_df=test_df.copy()
# Compute recipe outputs
# TODO: Write here your actual code that computes the outputs
# NB: DSS supports several kinds of APIs for reading and writing data. Please see doc.

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
jokes_info_df.head()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
my_jokes_df.head()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
rating_df.head()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import json
import math
n=len(set(rating_df["blague"]))  # N pour la formule
myprediction=[]
for i,j in rating_df.iterrows():
    #if(j[2]==99):
    #print(j[0])
    #blague=my_jokes_df[ ( my_jokes_df["user"]==j[0] ) & ( my_jokes_df["blague"]==int(j[1]) ) ].text
    tmpline=my_jokes_df[ ( my_jokes_df["id"]==j[1])      ]
    for k,l in tmpline.iterrows():
        blague=json.loads(l[1])

    #print("blah",len(blague))
    #notesUtils=jokes_info_df[jokes_info_df.user==j[0]]#note donné par le meme utilisateur

    predict=0
    i=0
    for mot in blague:
        dd=jokes_info_df[jokes_info_df["mot"]==mot]["dfm"].values
        if(len(dd)==0):
            continue

        #print(dd)
        dfmmot=dd[0]
        #print(mot+str(dfmmot))


        note=jokes_info_df[
            ( jokes_info_df["user"] == j[0] )
            &
            ( jokes_info_df["mot"]==mot   )
        ].moyenne_user.values

        if(len(note)>0):
            #print(note[0])
            #predict +=   math.log(n/dfmmot)  *  note[0]# on normalise avec +1 car sinon risquons d'avoir un 0
            predict +=   note[0]
            i+=1
        #print("note",note)
    #print("izan",predict)
    if(i!=0):
        note_moy=predict/i
    else:
        note_moy=0
    #print("je vais mettre a jour",note_moy)

    myprediction.append(note_moy)
    #print("note initiale",j[2],"prediction",note_moy)
rating_df["predictionNote"]=myprediction

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
model_recommandation_df = rating_df # Compute a Pandas dataframe to write into model_recommandation

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
model_recommandation_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Write recipe outputs
model_recommandation = dataiku.Dataset("model_recommandation")
model_recommandation.write_with_schema(model_recommandation_df)