# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
jokes_copy_to_join_prepared = dataiku.Dataset("jokes_copy_to_join_prepared")
jokes_copy_to_join_prepared_df = jokes_copy_to_join_prepared.get_dataframe()
jokes_tokenized_by_text = dataiku.Dataset("jokes_tokenized_by_text")
jokes_tokenized_by_text_df = jokes_tokenized_by_text.get_dataframe()

blague_text=jokes_copy_to_join_prepared_df.copy()
motDF=jokes_tokenized_by_text_df.copy()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
jokes_copy_to_join_prepared_df.head()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
jokes_tokenized_by_text_df.head()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import json
dfblague=[]
for i,j in jokes_copy_to_join_prepared_df.iterrows():
    blague=json.loads(j[1])
    mots=jokes_tokenized_by_text_df[( jokes_tokenized_by_text_df["text"].isin(blague))
                                   &
                                   (jokes_tokenized_by_text_df["dfm"]>15)
                                    (jokes_tokenized_by_text_df["dfm"]>15)
                                   ]["text"].values
    if(len(mots)==0):
        dfblague.append(15)
    else:
        dfblague.append()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Compute recipe outputs
# TODO: Write here your actual code that computes the outputs
# NB: DSS supports several kinds of APIs for reading and writing data. Please see doc.

phrase_to_mots_df = ... # Compute a Pandas dataframe to write into phrase_to_mots


# Write recipe outputs
phrase_to_mots = dataiku.Dataset("phrase_to_mots")
phrase_to_mots.write_with_schema(phrase_to_mots_df)