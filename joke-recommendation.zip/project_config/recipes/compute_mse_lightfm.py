# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import math

# Read recipe inputs
moteur_recomandation1 = dataiku.Dataset("moteur_recomandation1")
moteur_recomandation1_df = moteur_recomandation1.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
moteur_recomandation1_df.head()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
NbEchantillon=moteur_recomandation1_df.shape[0]
rmseGlobal=0
rmseUser={}
nbRankedUser={}
for i,j in moteur_recomandation1_df.iterrows():
    rmseGlobal+=(j[2]-j[3])**2

    if not (j[0] in rmseUser):
        rmseUser[j[0]]=0
    rmseUser[j[0]]+=(j[2]-j[3])**2
    if not (j[0] in nbRankedUser):
        nbRankedUser[j[0]]=1
    else:
        nbRankedUser[j[0]]+=1
rmseGlobal/=NbEchantillon
rmseGlobal=math.sqrt(rmseGlobal)
for user in rmseUser.keys():
    rmseUser[user]/=nbRankedUser[user]
    rmseUser[user]=math.sqrt(rmseUser[user])

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
rmseUser

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
dflist=[]
for user in rmseUser.keys():
    #print(rmseGlobal)
    d=[user,rmseUser[user],rmseGlobal]
    #print(d)
    dflist.append([int(user),rmseUser[user],rmseGlobal])
dfFinal=pd.DataFrame(dflist,columns=["user","rmseUser","rmsGlobal"])

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
dfFinal.head()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.


# Write recipe outputs
calcul_rmse = dataiku.Dataset("mse_lightfm")
calcul_rmse.write_with_schema(dfFinal)